
import * as Sentry from "@sentry/nextjs";

const isProduction = process.env.NODE_ENV === 'production';

// We only want to enable Session Replay in production to avoid "Multiple Sentry Session Replay instances" errors during local HMR.
// If you need to test Replay locally, temporarily set this to true.
const enableReplay = isProduction;

Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,

  // Adjust this value in production, or use tracesSampler for greater control
  tracesSampleRate: isProduction ? 0.1 : 1.0,

  // Setting this option to true will print useful information to the console while you're setting up Sentry.
  debug: false,

  replaysOnErrorSampleRate: 1.0,

  // This sets the sample rate to be 10%. You may want this to be 100% while
  // in development and sample at a lower rate in production
  replaysSessionSampleRate: isProduction ? 0.01 : 0.1,

  // You can remove this option if you're not planning to use the Sentry Session Replay feature:
  integrations: enableReplay ? [
    Sentry.replayIntegration({
      // Additional Replay configuration goes here, for example:
      maskAllText: true,
      blockAllMedia: true,
    }),
  ] : [],
});
