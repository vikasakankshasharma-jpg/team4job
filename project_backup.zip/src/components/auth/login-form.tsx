
"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { useUser } from "@/hooks/use-user";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Eye, EyeOff } from "lucide-react";
import { useState, useEffect } from "react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useTranslations } from "next-intl";

const formSchema = z.object({
  identifier: z.string().refine((val) => {
    const isEmail = z.string().email().safeParse(val).success;
    const isMobile = /^\d{10}$/.test(val);
    return isEmail || isMobile;
  }, { message: "validation.identifierReq" }),
  password: z.string().min(1, { message: "validation.passwordReq" }),
});

const MAX_LOGIN_ATTEMPTS = typeof window !== 'undefined' && window.location.hostname === 'localhost' ? 10 : 5;
const LOCKOUT_DURATION_SECONDS = 60;

export function LoginForm() {
  const router = useRouter();
  const { login, user } = useUser();
  const { toast } = useToast();
  const t = useTranslations("auth");
  const [isLoading, setIsLoading] = useState(false);
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [lockoutUntil, setLockoutUntil] = useState<Date | null>(null);
  const [remainingTime, setRemainingTime] = useState(0);
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (lockoutUntil) {
      const updateRemainingTime = () => {
        const now = new Date();
        const timeLeft = Math.max(0, Math.ceil((lockoutUntil.getTime() - now.getTime()) / 1000));
        setRemainingTime(timeLeft);
        if (timeLeft === 0) {
          setLockoutUntil(null);
          setLoginAttempts(0);
          clearInterval(interval);
        }
      };
      updateRemainingTime();
      interval = setInterval(updateRemainingTime, 1000);
    }
    return () => clearInterval(interval);
  }, [lockoutUntil]);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      identifier: "",
      password: "",
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    console.log("LoginForm: onSubmit called", values.identifier);
    if (lockoutUntil) return;

    setIsLoading(true);
    // basic demo check - still useful if user types dummy email
    const isDemoUser = values.identifier.endsWith("@example.com");
    console.log("LoginForm: Calling login...");
    const success = await login(values.identifier, values.password);
    console.log("LoginForm: Login result:", success);

    if (success) {
      // A small delay to allow user context to update before redirect
      setTimeout(() => {
        console.log("LoginForm: Redirecting to dashboard...");
        const isFirstLogin = !user?.lastLoginAt; // This is a simplified check
        if (isDemoUser || isFirstLogin) {
          router.push("/dashboard?tour=true");
        } else {
          router.push("/dashboard");
        }
      }, 500);
    } else {
      console.log("LoginForm: Login failed");
      const newAttemptCount = loginAttempts + 1;
      setLoginAttempts(newAttemptCount);

      if (newAttemptCount >= MAX_LOGIN_ATTEMPTS) {
        const newLockoutUntil = new Date(new Date().getTime() + LOCKOUT_DURATION_SECONDS * 1000);
        setLockoutUntil(newLockoutUntil);
        toast({
          title: t('tooManyAttempts'),
          description: t('lockoutDescription', { seconds: LOCKOUT_DURATION_SECONDS }),
          variant: "destructive",
        });
      } else {
        toast({
          title: t('loginFailed'),
          description: t('invalidCredentials', { count: MAX_LOGIN_ATTEMPTS - newAttemptCount }),
          variant: "destructive",
        });
      }
      setIsLoading(false);
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" noValidate>
        {lockoutUntil && (
          <Alert variant="destructive">
            <AlertTitle>{t('loginLocked')}</AlertTitle>
            <AlertDescription>
              {t('lockoutDescription', { seconds: remainingTime })}
            </AlertDescription>
          </Alert>
        )}
        <FormField
          control={form.control}
          name="identifier"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('emailMobileLabel')}</FormLabel>
              <FormControl>
                <Input placeholder={t('emailMobilePlaceholder')} {...field} disabled={!!lockoutUntil} className="h-11" autoComplete="username" aria-label={t('emailMobileLabel')} />
              </FormControl>
              <FormMessage data-testid="email-error">
                {form.formState.errors.identifier?.message && t(form.formState.errors.identifier.message)}
              </FormMessage>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('passwordLabel')}</FormLabel>
              <FormControl>
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder={t('passwordPlaceholder')}
                    {...field}
                    disabled={!!lockoutUntil}
                    className="h-11 pr-12"
                    autoComplete="current-password"
                    aria-label={t('passwordLabel')}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent z-10"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                    ) : (
                      <Eye className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                    )}
                    <span className="sr-only">{showPassword ? t('hidePassword') : t('showPassword')}</span>
                  </Button>
                </div>
              </FormControl>
              <FormMessage data-testid="password-error" />
            </FormItem>
          )}
        />
        <Button type="submit" className="w-full h-11" disabled={isLoading || !!lockoutUntil} data-testid="login-submit-btn">
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Log In
        </Button>
      </form>
    </Form>
  );
}
