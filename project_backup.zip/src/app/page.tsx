import HomeClient from '@/components/home-client';

export default function Home() {
  return <HomeClient />;
}
