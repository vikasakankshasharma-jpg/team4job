"use client";

import { useState, useEffect } from "react";
import { useUser } from "@/hooks/use-user";
import { useTranslations } from "next-intl";
import { useFirestore } from "@/lib/firebase/client-provider";
import { collection, query, where, getDocs, orderBy, limit } from "firebase/firestore";
import type { PendingSignup } from "@/lib/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Phone, Mail, MessageSquare, MoreVertical, Calendar, XCircle, Star, History, AlertCircle, RefreshCw } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { StatusBadge } from "@/components/pending-signups/status-badge";
import { PriorityBadge } from "@/components/pending-signups/priority-badge";
import { ScheduleFollowUpDialog } from "@/components/pending-signups/schedule-followup-dialog";
import { MarkAsDeniedDialog } from "@/components/pending-signups/mark-denied-dialog";
import { ActivityTimelineDialog } from "@/components/pending-signups/activity-timeline-dialog";
import {
    scheduleFollowUp,
    markAsDenied,
    addActivityLog,
    updateSignupStatus,
    getTodaysFollowUps,
    getOverdueFollowUps,
} from "@/lib/followup-manager";

export default function PendingSignupsClient() {
    const { user, isAdmin } = useUser();
    const t = useTranslations("admin.pendingSignups");
    const db = useFirestore();
    const { toast } = useToast();

    const [signups, setSignups] = useState<PendingSignup[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState("");
    const [statusFilter, setStatusFilter] = useState("all");
    const [priorityFilter, setPriorityFilter] = useState("all");
    const [roleFilter, setRoleFilter] = useState("all");
    const [activeTab, setActiveTab] = useState("all");

    // Dialog states
    const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
    const [denialDialogOpen, setDenialDialogOpen] = useState(false);
    const [timelineDialogOpen, setTimelineDialogOpen] = useState(false);
    const [selectedSignup, setSelectedSignup] = useState<PendingSignup | null>(null);

    // Manual Fetch
    const fetchSignups = async () => {
        if (!db || !isAdmin) return;
        setLoading(true);
        try {
            const q = query(
                collection(db, "pending_signups"),
                where("converted", "==", false),
                orderBy("lastActiveAt", "desc"),
                limit(100) // Safety limit
            );

            // Manual Get instead of Listener
            const snapshot = await getDocs(q);
            const data = snapshot.docs.map((doc) => ({
                ...doc.data(),
                id: doc.id,
            })) as PendingSignup[];
            setSignups(data);
        } catch (error) {
            console.error("Error fetching pending signups:", error);
            toast({
                title: "Error",
                description: "Failed to load pending signups.",
                variant: "destructive"
            });
        } finally {
            setLoading(false);
        }
    };

    // Initial Load
    useEffect(() => {
        fetchSignups();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [db, isAdmin]);

    if (!isAdmin) {
        return <div className="p-8 text-center">Access denied. Admin only.</div>;
    }

    if (loading) {
        return (
            <div className="flex items-center justify-center h-96">
                <Loader2 className="h-8 w-8 animate-spin" />
            </div>
        );
    }

    // Helper function
    const toDate = (timestamp: any) => {
        if (!timestamp) return new Date();
        if (timestamp instanceof Date) return timestamp;
        return timestamp.toDate();
    };

    // Filter signups
    const filteredSignups = signups.filter((signup) => {
        const matchesSearch =
            signup.mobile.includes(searchQuery) ||
            signup.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            signup.name?.toLowerCase().includes(searchQuery.toLowerCase());

        const matchesStatus = statusFilter === "all" || signup.status === statusFilter;
        const matchesPriority = priorityFilter === "all" || signup.priority === priorityFilter;
        const matchesRole = roleFilter === "all" || signup.role === roleFilter;

        return matchesSearch && matchesStatus && matchesPriority && matchesRole;
    });

    // Tab-specific filtering
    const getTabSignups = () => {
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);

        switch (activeTab) {
            case "today":
                return filteredSignups.filter((s) => {
                    if (!s.followUpDate) return false;
                    const followUpDate = toDate(s.followUpDate);
                    return followUpDate >= today && followUpDate < tomorrow;
                });
            case "overdue":
                return filteredSignups.filter((s) => {
                    if (!s.followUpDate) return false;
                    return toDate(s.followUpDate) < now && s.status !== "denied";
                });
            case "high_priority":
                return filteredSignups.filter((s) => s.priority === "high");
            default:
                return filteredSignups;
        }
    };

    const tabSignups = getTabSignups();

    // Stats
    const stats = {
        total: signups.filter((s) => !s.converted).length,
        new: signups.filter((s) => s.status === "new").length,
        contacted: signups.filter((s) => s.status === "contacted" || s.contacted).length,
        followUp: signups.filter((s) => s.status === "follow_up").length,
        denied: signups.filter((s) => s.status === "denied").length,
        today: signups.filter((s) => {
            if (!s.followUpDate) return false;
            const followUpDate = toDate(s.followUpDate);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const tomorrow = new Date(today);
            tomorrow.setDate(tomorrow.getDate() + 1);
            return followUpDate >= today && followUpDate < tomorrow;
        }).length,
        overdue: signups.filter((s) => {
            if (!s.followUpDate) return false;
            return toDate(s.followUpDate) < new Date() && s.status !== "denied";
        }).length,
    };

    // Action handlers
    const handleScheduleFollowUp = async (data: any) => {
        if (!selectedSignup || !db || !user) return;

        try {
            await scheduleFollowUp(
                db,
                selectedSignup.mobile,
                data.date,
                data.priority,
                user.id,
                user.name || "Admin",
                data.notes,
                data.nextAction
            );

            toast({
                title: "Follow-up scheduled",
                description: `Scheduled for ${data.date.toLocaleString()}`,
            });
        } catch (error) {
            console.error("Error scheduling follow-up:", error);
            toast({
                title: "Error",
                description: "Failed to schedule follow-up",
                variant: "destructive",
            });
        }
    };

    const handleMarkDenied = async (data: any) => {
        if (!selectedSignup || !db || !user) return;

        try {
            await markAsDenied(
                db,
                selectedSignup.mobile,
                data.reason,
                data.customReason,
                user.id,
                user.name || "Admin",
                data.notes
            );

            toast({
                title: "Marked as denied",
                description: "User has been marked as denied",
            });
        } catch (error) {
            console.error("Error marking as denied:", error);
            toast({
                title: "Error",
                description: "Failed to mark as denied",
                variant: "destructive",
            });
        }
    };

    const handleAddActivity = async (signup: PendingSignup, action: "call" | "sms" | "email") => {
        if (!db || !user) return;

        try {
            await addActivityLog(
                db,
                signup.mobile,
                user.id,
                user.name || "Admin",
                action,
                undefined,
                `Contacted via ${action}`
            );

            toast({
                title: "Activity logged",
                description: `${action.toUpperCase()} contact logged`,
            });
        } catch (error) {
            console.error("Error logging activity:", error);
            toast({
                title: "Error",
                description: "Failed to log activity",
                variant: "destructive",
            });
        }
    };

    const handleSetPriority = async (signup: PendingSignup, priority: "high" | "medium" | "low") => {
        if (!db || !user) return;

        try {
            await updateSignupStatus(db, signup.mobile, signup.status, priority, user.id, user.name || "Admin");
            toast({
                title: "Priority updated",
                description: `Set to ${priority} priority`,
            });
        } catch (error) {
            console.error("Error updating priority:", error);
            toast({
                title: "Error",
                description: "Failed to update priority",
                variant: "destructive",
            });
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-row items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold tracking-tight">{t("title")}</h1>
                    <p className="text-muted-foreground">{t("description")}</p>
                </div>
                <Button onClick={fetchSignups} variant="outline" size="sm" className="gap-2">
                    <RefreshCw className="h-4 w-4" />
                    {t("refresh")}
                </Button>
            </div>

            {/* Stats Cards */}
            <div className="grid gap-4 md:grid-cols-4 lg:grid-cols-7">
                <Card>
                    <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium">{t("stats.total")}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{stats.total}</div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium">{t("stats.new")}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{stats.new}</div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium">{t("stats.contacted")}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{stats.contacted}</div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium">{t("stats.followUp")}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{stats.followUp}</div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium">{t("stats.today")}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold text-orange-600">{stats.today}</div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium">{t("stats.overdue")}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold text-red-600">{stats.overdue}</div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium">{t("stats.denied")}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold text-gray-500">{stats.denied}</div>
                    </CardContent>
                </Card>
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList>
                    <TabsTrigger value="all">{t("tabs.all")} ({filteredSignups.length})</TabsTrigger>
                    <TabsTrigger value="today">
                        {t("tabs.today")} ({stats.today})
                        {stats.today > 0 && <Badge className="ml-2 bg-orange-500">{stats.today}</Badge>}
                    </TabsTrigger>
                    <TabsTrigger value="overdue">
                        {t("tabs.overdue")} ({stats.overdue})
                        {stats.overdue > 0 && <Badge className="ml-2 bg-red-500">{stats.overdue}</Badge>}
                    </TabsTrigger>
                    <TabsTrigger value="high_priority">
                        {t("tabs.highPriority")}
                    </TabsTrigger>
                </TabsList>

                <TabsContent value={activeTab} className="space-y-4">
                    {/* Filters */}
                    <div className="flex flex-col gap-4 md:flex-row md:items-end">
                        <div className="flex-1">
                            <Input
                                placeholder={t("filters.searchPlaceholder")}
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                            />
                        </div>

                        <Select value={statusFilter} onValueChange={setStatusFilter}>
                            <SelectTrigger className="w-[180px]">
                                <SelectValue placeholder={t("filters.status")} />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">{t("filters.allStatuses")}</SelectItem>
                                <SelectItem value="new">{t("badges.status.new")}</SelectItem>
                                <SelectItem value="contacted">{t("badges.status.contacted")}</SelectItem>
                                <SelectItem value="follow_up">{t("badges.status.follow_up")}</SelectItem>
                                <SelectItem value="busy">{t("badges.status.busy")}</SelectItem>
                                <SelectItem value="denied">{t("badges.status.denied")}</SelectItem>
                            </SelectContent>
                        </Select>

                        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                            <SelectTrigger className="w-[180px]">
                                <SelectValue placeholder={t("filters.priority")} />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">{t("filters.allPriorities")}</SelectItem>
                                <SelectItem value="high">{t("badges.priority.high")}</SelectItem>
                                <SelectItem value="medium">{t("badges.priority.medium")}</SelectItem>
                                <SelectItem value="low">{t("badges.priority.low")}</SelectItem>
                            </SelectContent>
                        </Select>

                        <Select value={roleFilter} onValueChange={setRoleFilter}>
                            <SelectTrigger className="w-[180px]">
                                <SelectValue placeholder={t("filters.role")} />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">{t("filters.allRoles")}</SelectItem>
                                <SelectItem value="Installer">{t("filters.installer")}</SelectItem>
                                <SelectItem value="Job Giver">{t("filters.jobGiver")}</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    {/* Table */}
                    <Card>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>{t("table.contact")}</TableHead>
                                    <TableHead>{t("table.status")}</TableHead>
                                    <TableHead>{t("table.priority")}</TableHead>
                                    <TableHead>{t("table.role")}</TableHead>
                                    <TableHead>{t("table.followUp")}</TableHead>
                                    <TableHead>{t("table.lastActive")}</TableHead>
                                    <TableHead>{t("table.attempts")}</TableHead>
                                    <TableHead>{t("table.actions")}</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {tabSignups.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                                            No pending signups found
                                        </TableCell>
                                    </TableRow>
                                ) : (
                                    tabSignups.map((signup) => (
                                        <TableRow key={signup.id} className="cursor-pointer hover:bg-muted/50">
                                            <TableCell>
                                                <div className="font-medium">{signup.mobile}</div>
                                                <div className="text-sm text-muted-foreground">{signup.email || "-"}</div>
                                                <div className="text-sm text-muted-foreground">{signup.name || "-"}</div>
                                            </TableCell>
                                            <TableCell>
                                                <StatusBadge status={signup.status || "new"} />
                                            </TableCell>
                                            <TableCell>
                                                <PriorityBadge priority={signup.priority || "medium"} />
                                            </TableCell>
                                            <TableCell>
                                                {signup.role ? <Badge variant="outline">{signup.role}</Badge> : "-"}
                                            </TableCell>
                                            <TableCell>
                                                {signup.followUpDate ? (
                                                    <div className="text-sm">
                                                        {toDate(signup.followUpDate).toLocaleDateString()}
                                                        <br />
                                                        <span className="text-muted-foreground">
                                                            {toDate(signup.followUpDate).toLocaleTimeString([], {
                                                                hour: "2-digit",
                                                                minute: "2-digit",
                                                            })}
                                                        </span>
                                                    </div>
                                                ) : (
                                                    "-"
                                                )}
                                            </TableCell>
                                            <TableCell className="text-sm text-muted-foreground">
                                                {formatDistanceToNow(toDate(signup.lastActiveAt), { addSuffix: true })}
                                            </TableCell>
                                            <TableCell>
                                                <Badge variant="secondary">{signup.totalContactAttempts || 0}</Badge>
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex gap-2">
                                                    {/* Quick actions */}
                                                    <Button
                                                        size="sm"
                                                        variant="outline"
                                                        onClick={() => {
                                                            window.location.href = `tel:${signup.mobile}`;
                                                            handleAddActivity(signup, "call");
                                                        }}
                                                        title="Call"
                                                    >
                                                        <Phone className="h-4 w-4" />
                                                    </Button>
                                                    <Button
                                                        size="sm"
                                                        variant="outline"
                                                        onClick={() => {
                                                            window.location.href = `sms:${signup.mobile}`;
                                                            handleAddActivity(signup, "sms");
                                                        }}
                                                        title="SMS"
                                                    >
                                                        <MessageSquare className="h-4 w-4" />
                                                    </Button>
                                                    {signup.email && (
                                                        <Button
                                                            size="sm"
                                                            variant="outline"
                                                            onClick={() => {
                                                                window.location.href = `mailto:${signup.email}`;
                                                                handleAddActivity(signup, "email");
                                                            }}
                                                            title="Email"
                                                        >
                                                            <Mail className="h-4 w-4" />
                                                        </Button>
                                                    )}

                                                    {/* More actions dropdown */}
                                                    <DropdownMenu>
                                                        <DropdownMenuTrigger asChild>
                                                            <Button size="sm" variant="ghost">
                                                                <MoreVertical className="h-4 w-4" />
                                                            </Button>
                                                        </DropdownMenuTrigger>
                                                        <DropdownMenuContent align="end">
                                                            <DropdownMenuLabel>{t("table.actions")}</DropdownMenuLabel>
                                                            <DropdownMenuSeparator />
                                                            <DropdownMenuItem
                                                                onClick={() => {
                                                                    setSelectedSignup(signup);
                                                                    setScheduleDialogOpen(true);
                                                                }}
                                                            >
                                                                <Calendar className="mr-2 h-4 w-4" />
                                                                {t("actions.schedule")}
                                                            </DropdownMenuItem>
                                                            <DropdownMenuItem
                                                                onClick={() => {
                                                                    setSelectedSignup(signup);
                                                                    setDenialDialogOpen(true);
                                                                }}
                                                            >
                                                                <XCircle className="mr-2 h-4 w-4" />
                                                                {t("actions.markDenied")}
                                                            </DropdownMenuItem>
                                                            <DropdownMenuItem
                                                                onClick={() => {
                                                                    setSelectedSignup(signup);
                                                                    setTimelineDialogOpen(true);
                                                                }}
                                                            >
                                                                <History className="mr-2 h-4 w-4" />
                                                                {t("actions.viewTimeline")}
                                                            </DropdownMenuItem>
                                                            <DropdownMenuSeparator />
                                                            <DropdownMenuLabel>{t("actions.setPriority")}</DropdownMenuLabel>
                                                            <DropdownMenuItem onClick={() => handleSetPriority(signup, "high")}>
                                                                <Star className="mr-2 h-4 w-4 text-red-500" />
                                                                {t("badges.priority.high")} ({t("stats.highPriority")})
                                                            </DropdownMenuItem>
                                                            <DropdownMenuItem onClick={() => handleSetPriority(signup, "medium")}>
                                                                <Star className="mr-2 h-4 w-4 text-yellow-500" />
                                                                {t("badges.priority.medium")}
                                                            </DropdownMenuItem>
                                                            <DropdownMenuItem onClick={() => handleSetPriority(signup, "low")}>
                                                                <Star className="mr-2 h-4 w-4 text-gray-500" />
                                                                {t("badges.priority.low")}
                                                            </DropdownMenuItem>
                                                        </DropdownMenuContent>
                                                    </DropdownMenu>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                        </Table>
                    </Card>
                </TabsContent>
            </Tabs>

            {/* Dialogs */}
            <ScheduleFollowUpDialog
                open={scheduleDialogOpen}
                onOpenChange={setScheduleDialogOpen}
                onSchedule={handleScheduleFollowUp}
                userName={selectedSignup?.name || selectedSignup?.mobile}
            />

            <MarkAsDeniedDialog
                open={denialDialogOpen}
                onOpenChange={setDenialDialogOpen}
                onDeny={handleMarkDenied}
                userName={selectedSignup?.name || selectedSignup?.mobile}
            />

            <ActivityTimelineDialog
                open={timelineDialogOpen}
                onOpenChange={setTimelineDialogOpen}
                activities={selectedSignup?.activityLog || []}
                userName={selectedSignup?.name || selectedSignup?.mobile}
            />
        </div>
    );
}
