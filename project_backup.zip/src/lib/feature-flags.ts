
import { getAdminDb } from "@/infrastructure/firebase/admin";
import { doc, getDoc, onSnapshot } from "firebase/firestore"; // For client-side if needed, but we usually use a hook.
import { useState, useEffect } from "react";
import { useFirebase } from "@/hooks/use-user";

export type FeatureFlagKey = 'ENABLE_PAYMENTS' | 'ENABLE_AI_GENERATION' | 'ENABLE_DISPUTES_V2';

export const DEFAULT_FLAGS: Record<FeatureFlagKey, boolean> = {
    'ENABLE_PAYMENTS': true, // Defaulting to true for now, can be toggled to false if needed.
    'ENABLE_AI_GENERATION': true,
    'ENABLE_DISPUTES_V2': true,
};

// SERVER-SIDE Usage
export async function getFeatureFlag(key: FeatureFlagKey): Promise<boolean> {
    try {
        const db = getAdminDb();
        const docRef = db.collection('feature_flags').doc(key);
        const docSnap = await docRef.get();

        if (docSnap.exists) {
            return docSnap.data()?.isEnabled ?? DEFAULT_FLAGS[key];
        }
        return DEFAULT_FLAGS[key];
    } catch (error) {
        console.error(`[FeatureFlag] Failed to fetch flag ${key}:`, error);
        return DEFAULT_FLAGS[key];
    }
}

// CLIENT-SIDE Hook
export function useFeatureFlag(key: FeatureFlagKey) {
    const { db } = useFirebase();
    const [isEnabled, setIsEnabled] = useState<boolean>(DEFAULT_FLAGS[key]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!db) return;

        const ref = doc(db, 'feature_flags', key);
        const unsubscribe = onSnapshot(ref, (snap) => {
            if (snap.exists()) {
                setIsEnabled(snap.data()?.isEnabled ?? DEFAULT_FLAGS[key]);
            } else {
                setIsEnabled(DEFAULT_FLAGS[key]);
            }
            setLoading(false);
        }, (error) => {
            console.error(`[FeatureFlag] Subscription error for ${key}:`, error);
            setLoading(false);
        });

        return () => unsubscribe();
    }, [db, key]);

    return { isEnabled, loading };
}
