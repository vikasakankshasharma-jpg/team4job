import CalendarClient from "./calendar-client";

export const dynamic = "force-dynamic";

export default function CalendarPage() {
    return <CalendarClient />;
}
